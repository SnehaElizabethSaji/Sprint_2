package com.cg.hcsAdmin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hcsAdmin.dto.Patient;

public interface PatientDAO extends JpaRepository<Patient, Integer>
{
	
}
