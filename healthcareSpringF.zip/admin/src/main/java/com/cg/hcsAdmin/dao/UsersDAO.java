package com.cg.hcsAdmin.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hcsAdmin.dto.Users;

public interface UsersDAO extends JpaRepository<Users, String>
{

}
