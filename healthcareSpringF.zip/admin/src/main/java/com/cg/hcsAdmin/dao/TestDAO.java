package com.cg.hcsAdmin.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.hcsAdmin.dto.Test;

@Repository
public interface TestDAO extends JpaRepository<Test, Integer>
{
	
}
