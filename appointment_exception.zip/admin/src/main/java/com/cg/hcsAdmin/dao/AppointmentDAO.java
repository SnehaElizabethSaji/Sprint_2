package com.cg.hcsAdmin.dao;

import java.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.hcsAdmin.dto.Appointment;
@Repository
public interface AppointmentDAO extends JpaRepository<Appointment,Integer> 
{
	
	public Appointment getAppointmentByCenterIdAndAppointmentDate(int centerId,LocalDate appointmentDate);
}

