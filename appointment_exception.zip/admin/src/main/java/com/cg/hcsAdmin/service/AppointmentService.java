package com.cg.hcsAdmin.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hcsAdmin.dao.AppointmentDAO;
import com.cg.hcsAdmin.dto.Appointment;

@Service
public class AppointmentService {
	@Autowired
    AppointmentDAO adao;
    public void setAdao(   AppointmentDAO adao) 
    { 
    	this.adao=adao;
    	} 
    @Transactional
    public Appointment insertAppointment(Appointment appointment)
    {
        return adao.save(appointment);
    }
    @Transactional(readOnly = true)
    public Appointment getAppointmentByCenterIdAndAppointmentDate(int centerId,LocalDate appointmentDate)
    {
    	return adao.getAppointmentByCenterIdAndAppointmentDate(centerId,appointmentDate);
    }
    @Transactional(readOnly=true)
    public Optional<Appointment> getAppointment(Integer appointmentId)
    {
    	return adao.findById(appointmentId);
    }
 }


