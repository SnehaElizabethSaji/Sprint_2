package com.cg.hcsAdmin.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.cg.hcsAdmin.dto.Test;

@Service
public interface TestDAO extends JpaRepository<Test, Integer>
{
	
}
